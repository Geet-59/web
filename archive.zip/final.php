<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "last-name_first-name";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO last-name_first-name (Last name, first name, City, age);

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

 if (isset($_POST['submit'])) {
 $lname = $_POST["Last name"];
 $fname = $_POST["first name"];
 $City = $_POST["City"];
 $Age = $_POST["age"];

echo "Last Name is = ". $lname  ;
echo "first Name is = ". $fname ;
echo "City is = ". $City ;
echo "Age is = ". $Age;
 }

?>
